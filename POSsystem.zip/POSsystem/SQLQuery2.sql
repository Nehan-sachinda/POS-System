﻿INSERT INTO Customers (Name, Email, Phone)
VALUES
('John Doe', 'john@example.com', '1234567890'),
('Jane Smith', 'jane@example.com', '9876543210');
INSERT INTO Products (ProductName, Quantity, Price)
VALUES
('Apple', 100, 1.20),
('Banana', 150, 0.80),
('Orange', 200, 1.50);
INSERT INTO Users (Username, PasswordHash, Role)
VALUES
('admin', 'admin123', 'Admin'),
('user1', 'password123', 'User');
